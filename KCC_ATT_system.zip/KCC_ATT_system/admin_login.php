<?php

session_start();
include ('Connection/dbConnection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $qr = $_POST['qr_value'];
    $check = mysqli_query($conn, "SELECT * FROM registered_admin WHERE student_id_number='$qr'");

    if (mysqli_num_rows($check) > 0) {
        $_SESSION['admin'] = $qr;
        echo "<script>alert('Welcome Admin!'); window.location='home.php';</script>";
        exit;
    } else {
        echo "<script>alert('Invalid QR code');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin QR Login</title>
    <script src="https://unpkg.com/html5-qrcode"></script>
</head>
<body>
    <h3>📷 Scan Admin QR Code</h3>
    <div id="reader" style="width:250px;"></div>

    <form method="POST">
        <input type="hidden" name="qr_value" id="qr_value">
    </form>

    <button onclick="window.location='admin_register.php'">Register</button>

    <script>
        const scanner = new Html5Qrcode("reader");
        scanner.start(
            { facingMode: "environment" },
            { fps: 3, qrbox: 200 },
            qrCodeMessage => {
                document.getElementById('qr_value').value = qrCodeMessage;
                document.forms[0].submit();
                scanner.stop();
            },
            error => {}
        ).catch(err => {
            alert("Camera error: " + err);
        });
    </script>
</body>
</html>
