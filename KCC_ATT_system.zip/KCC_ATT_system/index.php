<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Kccians!</title>
    <link rel='icon' href='index_img/KCC_NEW_LOGO.png'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/index.css">
</head>
<body style="background: url('index_img/pic1.png') no-repeat center center fixed; background-size: cover;">
    <header>
        <div class="topbar">
                <img style="width: 70px; height: 70px; " src="index_img/KCC_NEW_LOGO.png" alt="">
                <img style="width: 80px; height: 80px; "src="index_img/KCC_FIT.png" alt="">
            <div class="buttons">
                <a href="student_register.php" class="btn btn-primary">Student Register</a>
                <a href="admin_login.php" class="btn btn-primary">Admin Login</a>
            </div>
        </div>
    </header>

    <footer>
      <p>Ver. 1.0 Dev. Secret</p>
    </footer>
</body>


</html>