<?php

include_once ('Connection/dbConnection.php');
include_once('QRCODE/phpqrcode/qrlib.php');

if(isset($_POST['submit'])) {

    $student_id_number = $_POST['student_id_number'];
    $full_name         = $_POST['full_name'];
    $course            = $_POST['course'];
    $year_level        = $_POST['year_level'];
    $section           = $_POST['section'];

    $checkQuery = "SELECT * FROM register WHERE student_id_number = '$student_id_number'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
    echo '<script>
            alert("⚠️ Student ID already registered!");
            window.location.href = "index.php";
          </script>';
    exit();
}

   
    $query = "INSERT INTO `register`(`student_id_number`, `full_name`, `course`, `year_level`, `section`) 
    VALUES ('$student_id_number','$full_name','$course','$year_level','$section')";

    $result = mysqli_query($conn, $query); 

    if ($result) {
        $qr_content = "$student_id_number | $full_name | $course | $year_level | $section";
        $filename = "QRCODE/Student_QR/" . $full_name.".png";
        QRcode::png($qr_content, $filename, 'H', 10, 10);

         echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Student Registered</title>
        <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
        <link rel='icon' href='index_img/KCC_NEW_LOGO.png'>
        <style>
            body {
                background: url('index_img/pic1.png') no-repeat center center fixed;
                background-size: cover;
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
            .card {
                justify-content: center;
                align-items: center;
                max-width: 380px;
                background-color: rgba(255,255,255,0.9);
                border-radius: 15px;
                box-shadow: 0 4px 10px rgba(0,0,0,0.3);
                padding: 20px;
            }
        </style>
    </head>
    <body>
        <div class='card text-center'>
            <h3 class='text-success'>Student Registered!</h3>
            <p>QR Code for: <b>$full_name</b></p>
            <img src='$filename' class='img-fluid' style='max-width:200px;' alt='QR Code'><br>
            <a href='$filename' download class='btn btn-success mt-3 w-100'>Download QR Code</a>
            <hr>
            <p class='text-danger small'>
                ⚠️ This QR code is personal and should not be shared.<br>
                Using it while you're not present is a violation.
            </p>
            <a href='index.php' class='btn btn-secondary w-100 mt-2'>Back</a>
        </div>
    </body>
    </html>";
    exit();
}

    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Attendance System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="icon" href="index_img/KCC_NEW_LOGO.png">
  <style>
    body {
      background: url('index_img/pic1.png') no-repeat center center fixed;
      background-size: cover;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .card {
      width: 100%;
      max-width: 400px;
      background-color: rgba(255, 255, 255, 0.9);
      border-radius: 15px;
      box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
    }

    h2 {
      font-weight: bold;
      color: #333;
    }

    .intro {
      text-align: center;
      background-color: #6c80c06b;
      border-radius: 10px;
      opacity: 40%;
    }

    label {
      font-weight: 500;
    }

    footer {
      font-size: 12px;
      height: auto;
      margin-top: 20px;
      margin-bottom: 0px;
      text-align: center;
      justify-content: center;
      align-items: center;
      font-weight: 200;
    }

    @media (max-width: 576px) {
      body {
        background-size: cover;
        padding: 20px;
      }
      .card {
        padding: 15px;
      }

    }
  </style>
</head>
<body>
  <div class="card shadow-lg p-4">
    <h2 class="text-center mb-4">
      Register 
      <span>
        <img src="index_img/KCC_NEW_LOGO.png" class="img-fluid" style="width: 45px; height: 45px;" alt="KCC Logo">
      </span>
    </h2>
    <p class="intro">Hello KCCians! Manage your attendance easily with our QR system.</p>

    <form method="POST" action="">
      <div class="mb-3">
        <label>Student ID Number</label>
        <input class="form-control" type="text" name="student_id_number" placeholder="10-Digit Number" required>
      </div>

      <div class="mb-3">
        <label>Student Name</label>
        <input class="form-control" type="text" name="full_name" placeholder="Lastname, Firstname, Middlename" required>
      </div>
      
      <div class="mb-3">
        <label>Course</label>
        <input class="form-control" type="text" name="course" placeholder="ex. BSIT" required>
      </div>

      <div class="mb-3">
        <select name="year_level" class="form-select" required>
          <option value=""disabled selected>Select Year Level</option>
          <option value="1">1st Year</option>
          <option value="2">2nd Year</option>
          <option value="3">3rd Year</option>
          <option value="4">4th Year</option>
        </select>
      </div>

      <div class="mb-3">
         <select name="section" class="form-select" required>
          <option value=""disabled selected>Select Section</option>
          <option value="A">Section A</option>
          <option value="B">Section B</option>
          <option value="C">Section C</option>
          <option value="D">Section D</option>
          <option value="E">Section E</option>
          <option value="F">Section F</option>
        </select>
      </div>

      <div class="d-flex justify-content-center mt-3">
        <button class="btn btn-primary w-100" type="submit" name="submit">Create QR Code</button>
      </div>
    </form>
    <footer>
      <p>Ver. 1.0 Dev. Secret</p>
    </footer>
  </div>
</body>
</html>
