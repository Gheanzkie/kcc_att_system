<?php

$conn = mysqli_connect("localhost", "root", "", "kcc_att_system");

if(mysqli_connect_error()) {
    echo "Connection Failed". mysqli_connect_error();
}
?>

